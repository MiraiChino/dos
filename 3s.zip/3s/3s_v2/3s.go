package main

import (
	"log"
	"sync"
	"time"
)

var wg sync.WaitGroup

func main() {
	wg.Add(3)
	go sleep(1)
	go sleep(2)
	go sleep(3)
	wg.Wait()
}

func sleep(sec int) {
	defer wg.Done()
	log.Printf("%ds", sec)
	time.Sleep(time.Duration(sec) * time.Second)
	log.Printf("%d done", sec)
}
