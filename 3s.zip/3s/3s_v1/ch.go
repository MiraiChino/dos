package main

import "log"

func main() {
	c := make(chan string)
	hello := func(msg string) { c <- msg }

	hello("World 1")
	hello("World 2")

	log.Print(<-c)
	log.Print(<-c)
}
