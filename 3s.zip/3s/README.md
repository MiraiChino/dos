<!-- page_number: true -->

# Go言語で、
# ６秒の直列処理を３秒にする

---

# Goってなに？
- Googleがつくったすごい言語
- Python並に読みやすい、C並に速い
![center](img/readability_vs_efficiency.png)
###### 参考：[Why should you learn Go? – Keval Patel – Medium](https://medium.com/@kevalpatel2106/why-should-you-learn-go-f607681fad65)

---

# なにがつくれる？
- Webアプリ
	- YouTubeはGoで書かれている
- ソフトウェア
	- Windows, Linux, Macを同じコードで書ける
	- Android, iOSを同じコードで書ける
- PaaS
	- Docker, KubernetesはGoで書かれている
###### 参考：[go言語（golang）の特徴って？メリットとデメリットをまとめてみた](https://itpropartners.com/blog/10984/)

---

# なんでGo？
<strong style="text-align:center; font-size:130px;">
並列処理が簡単に書ける!!!!!
</strong>


---

# 並列化をやってみたい
- 目標１：==６秒の直列処理を３秒でやる==　←今回はここ
![center 20%](img/6s.png)
- 目標２：Google検索もどきをつくる
![center 50%](img/google.png)

---

# ６秒の直列処理を３秒でやる
![center](img/6s.png)

---

# ６秒の直列処理
6s.go

``` go
func main() {
    sleep(1)
    sleep(2)
    sleep(3)
}

func sleep(sec int) {
    log.Printf("%ds", sec)
    time.Sleep(time.Duration(sec) * time.Second)
    log.Printf("%d done", sec)
}
```

---

# 3秒の並列処理
3s.go

``` go
func main() {
    go sleep(1)
    go sleep(2)
    go sleep(3)
}

func sleep(sec int) {
    log.Printf("%ds", sec)
    time.Sleep(time.Duration(sec) * time.Second)
    log.Printf("%d done", sec)
}
``` 

---

# なにが起きた？

<strong style="text-align:center; font-size:80px;">
sleep関数が終わる前に、main関数が終わった
</strong>

---

# channelで処理を待つ
![center 100%](img/chan.jpg)

``` go
func main() {
  c := make(chan string)
  hello := func(msg string) { c <- msg }

  hello("World 1")
  hello("World 2")

  // ２回channelを受け取るまで待つ
  log.Print(<-c)
  log.Print(<-c)
}
```


---

# 3秒の並列処理（channel版）
3s_ch.go

``` go
func main() {
    c := make(chan bool)
    go func() { sleep(1); c <- true }()
    go func() { sleep(2); c <- true }()
    go func() { sleep(3); c <- true }()
    <-c
    <-c
    <-c
}

func sleep(sec int) {
    log.Printf("%ds", sec)
    time.Sleep(time.Duration(sec) * time.Second)
    log.Printf("%d done", sec)
}
```
    
---

# 3秒の並列処理（WaitGroup版）
3s_wg.go

``` go
var wg sync.WaitGroup   # カウンタ

func main() {
    wg.Add(3)   # ３増やす
    go sleep(1)
    go sleep(2)
    go sleep(3)
    wg.Wait()   # ０になるまでまつ
}

func sleep(sec int) {
    defer wg.Done() # １減らす（関数の最後に実行）
    log.Printf("%ds", sec)
    time.Sleep(time.Duration(sec) * time.Second)
    log.Printf("%d done", sec)
}
```

---

# まとめ
Goだと簡単に並列化できる

``` go
go sleep(1)
go sleep(2)
go sleep(3)
```

![center 50%](img/6s.png)

---

# 次回：Google検索もどきをつくる
![center](img/google.png)

---

# 参考サイト
###### 参考：[Goルーチンで並行化する方法: 6秒かかる処理を3秒にしよう - Qiita](https://qiita.com/suin/items/82ecb6f63ff4104d4f5d)
###### 参考：[GoのChannelを使いこなせるようになるための手引 - Qiita](https://qiita.com/awakia/items/f8afa070c96d1c9a04c9)