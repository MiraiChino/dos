package main

import (
	"log"
	"time"
)

func main() {
	sleep(1)
	sleep(2)
	sleep(3)
}

func sleep(sec int) {
	log.Printf("%ds", sec)
	time.Sleep(time.Duration(sec) * time.Second)
	log.Printf("%d done", sec)
}
