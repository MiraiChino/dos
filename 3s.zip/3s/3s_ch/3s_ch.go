package main

import (
	"log"
	"time"
)

func main() {
	c := make(chan bool)
	go func() { sleep(1); c <- true }()
	go func() { sleep(2); c <- true }()
	go func() { sleep(3); c <- true }()
	<-c
	<-c
	<-c
}

func sleep(sec int) {
	log.Printf("%ds", sec)
	time.Sleep(time.Duration(sec) * time.Second)
	log.Printf("%d done", sec)
}
