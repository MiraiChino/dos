package main

import (
	"fmt"
	"math/rand"
	"time"
)

var (
	Web1   = fakeSearch("web 1")
	Image1 = fakeSearch("image 1")
	Video1 = fakeSearch("video 1")
	Web2   = fakeSearch("web 2")
	Image2 = fakeSearch("image 2")
	Video2 = fakeSearch("video 2")
)

type Search func(query string) Result
type Result string

func fakeSearch(kind string) Search {
	return func(query string) Result {
		duration := rand.Intn(100)
		time.Sleep(time.Duration(duration) * time.Millisecond)
		return Result(fmt.Sprintf("%s result for %q %d ms\n", kind, query, duration))
	}
}

func First(query string, replicas ...Search) Result {
	c := make(chan Result)
	searchReplica := func(i int) { c <- replicas[i](query) }
	for i := range replicas {
		go searchReplica(i)
	}
	return <-c
}

func main() {
	rand.Seed(time.Now().UnixNano())
	start := time.Now()
	results := Google("golang")
	elapsed := time.Since(start)
	fmt.Println(results)
	fmt.Println(elapsed)
}

func Google(query string) (results []Result) {
	c := make(chan Result)
	go func() { c <- First(query, Web1, Web2) }()
	go func() { c <- First(query, Image1, Image2) }()
	go func() { c <- First(query, Video1, Video2) }()
	timeout := time.After(80 * time.Millisecond)
	for i := 0; i < 3; i++ {
		select {
		case result := <-c:
			results = append(results, result)
		case <-timeout:
			fmt.Println("timed out")
			return
		}
	}
	return
}
